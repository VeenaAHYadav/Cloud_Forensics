# storage/save.py
import json

def save_evidence(logs, hashes):
    data = []

    for log, h in zip(logs, hashes):
        data.append({
            "log": log,
            "hash": h
        })

    with open("storage/db.json", "w") as f:
        json.dump(data, f, indent=4)