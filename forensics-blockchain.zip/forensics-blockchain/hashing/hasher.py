# hashing/hasher.py
import hashlib
import json

def generate_hash(log):
    return hashlib.sha256(
        json.dumps(log, sort_keys=True).encode()
    ).hexdigest()