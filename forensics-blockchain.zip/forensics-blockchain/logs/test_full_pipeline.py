import json
from hashing.hasher import generate_hash
from blockchain.web3_client import store_hash, get_hash, get_count

# Load test logs
with open("logs/test_logs.json", "r") as f:
    logs = json.load(f)

print("\n--- STEP 1: Hashing Logs ---")
hashes = []

for log in logs:
    h = generate_hash(log)
    hashes.append(h)
    print("Log:", log)
    print("Hash:", h, "\n")

print("\n--- STEP 2: Storing on Blockchain ---")
for h in hashes:
    store_hash(h)

print("Stored all hashes!")

print("\n--- STEP 3: Fetching from Blockchain ---")
count = get_count()
print("Total hashes on chain:", count)

print("\n--- STEP 4: Verification ---")
for i, log in enumerate(logs):
    local_hash = generate_hash(log)
    chain_hash = get_hash(i)

    if local_hash == chain_hash:
        print(f"Log {i}: OK ✅")
    else:
        print(f"Log {i}: TAMPERED ❌")

# 💣 STEP 5: Tampering Test
print("\n--- STEP 5: Tampering Simulation ---")
logs[0]["ip"] = 999  # modify log

for i, log in enumerate(logs):
    local_hash = generate_hash(log)
    chain_hash = get_hash(i)

    if local_hash == chain_hash:
        print(f"Log {i}: OK")
    else:
        print(f"Log {i}: TAMPERED ⚠️")